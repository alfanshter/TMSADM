<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CleaningCritical extends Model
{
    protected $guarded = [
        'id'
    ];

    public function activity()
    {
        return $this->belongsTo(ActivityTms::class, 'activity_tms_id');
    }
}
